// Script para actualizar precios en Bs automáticamente
